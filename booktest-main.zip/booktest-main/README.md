Capítulo cinquenta
Kratos parou diante do enorme espelho sobre a parede na Câmara de
Tecer de Cloto. Carretéis espessos estavam meticulosamente ordenados por
trás dele.
Envoltos em cada carretel, fios do destino tão grossos quanto seus
musculosos antebraços. Fora ele quem levara as bobinas àquele lugar e,
assim, logo notou como as trêmulas amarras corriam do espelho. Sacou a
Lança do Destino e observou atentamente como elas reagiam quando
tocava a ponta de sua lança contra a maior das amarras, marrom com
pequenas listras do verde selvagem.
Sua determinação se consolidou. Kratos brandiu a Lança do Destino e
saiu cortando um enorme fio após o outro até que todas as bobinas
sustentassem apenas as extremidades dos fios. Deu um passo à frente rumo
ao espelho e sentiu seu estômago revirar, ao fazer a transição para o outro
lado e voltar no tempo, uma viagem rumo a incontáveis séculos no
passado. Preparado para o deslocamento dessa vez, ele se viu no meio de
uma planície devastada com prédios em chamas por todas as direções em
que mirava.
O chão tremeu. Kratos ergueu os olhos e vislumbrou o que, a princípio,
confundiu com uma grande colina coberta de grama e uma pequena
floresta, o que em verdade era um Titã. Ele nunca tinha visto Gaia antes –
não em sua forma real –, mas aquela devia ser a Titã da terra.
Ela se elevou por quase meio quilômetro de altura, com nada além de
terra e vegetação formando seu corpo. Seios fartos e caídos do tamanho de
enormes galeões de guerra atestavam seu status como mãe de todos. Piscou
olhos marrons de sujeira e se dobrou bem baixo. Uma mão que parecia ter
sido coberta de lama e, em seguida, seca foi em direção a ele. Kratos não
recuou.
– Gaia!
– Nós estávamos esperando por você, Fantasma de Esparta. Os deuses
são poderosos demais para que os derrotemos agora.
– Todos no Olimpo irão tremer diante de meu nome! Zeus está fraco,
Ares e Atena estão mortos. E eu empunho a lâmina! Podemos vencer a
Grande Guerra, mas não neste tempo – ao longe, emergiram colunas
retorcidas e azuladas de pura energia, o contra-ataque dos deuses
revidando a última e vã ofensiva dos Titãs ao Olimpo. – Eu matei as Moiras
e cortei os fios do destino que elas tramaram para você em meu tempo.
Juntos, vamos matar os deuses mesquinhos e ver o Olimpo tremer diante
de nós.
Kratos foi banhado em uma energia coruscante. Ele se virou e sentiu a
atração do espelho do tempo atrás dele.
– Venha comigo, Gaia. Volte a meu tempo. A vitória nos espera.
Tempestades se formaram por todos os lados e ele ficou cego com tanta
chuva e poeira.
Sentado em seu trono, Zeus apertava os braços do sólio com tanta força
que a pedra acabou rachando. Dispostos diante dele, estavam os deuses e
deusas do Olimpo, todos apreensivos por terem sido convocados ao pé do
trono do Rei dos Deuses.
– Já enfrentamos coisa muito pior do que esse mortal decaído – Zeus
disse, com uma voz estrondosa e confiante. – Nós somos os deuses! Nós, a
quem os mortais adoram, nós que governamos sobre a terra, nós não
seremos varridos de lado por esses idiotas petulantes!
Zeus percebeu o mal-estar entre os deuses. Mesmo seus irmãos
Poseidon e Hades pareciam apreensivos.
– Irmãos, deixemos de lado as ofensas mesquinhas que nos separaram
por tanto tempo. Vamos nos unir, vamos ficar juntos, e eu vou exterminar
essa praga! O Olimpo prevalecerá!
Zeus se levantou em um pulo e cambaleou. Um terremoto sacudiu o lar
dos deuses. Estátuas racharam e partes delas desabaram, provocando um
barulho estrondoso. Ele deu um tapa em um pedaço da cúpula de sua
câmara de audiência que despencava perto demais de seu trono. Os deuses
correram rumo ao terraço e olharam para baixo. Zeus os seguiu, passando
por cima de colunas de mármore que haviam desabado no terremoto.
Ele piscou, surpreso. O mundo dos mortais pegava fogo. Por todos os
lugares, cidades ardiam em chamas. Uma devastação muito maior do que
qualquer coisa que ele já tinha visto tomava a paisagem de assalto.
Kratos ergueu os olhos rumo ao íngreme cume que sustentava o
Olimpo. Do alto de sua vantagem, no ombro de Gaia, não lhe pareceu
assim tão elevado. Ele se escorou no tronco de uma tília quando Gaia
passou a escalar. Por todos os lados, outros Titãs a acompanharam rumo à
longa escalada e o ataque ao Olimpo começou.
Kratos ergueu a Lâmina do Olimpo e a brandiu em direção a Zeus,
sabendo que o Rei dos Deuses o observava. Era impossível não perceber
que a batalha seria travada em breve.
Os Titãs despontaram no horizonte marcado pelas cicatrizes de batalha
e seguiram Gaia e os outros que já haviam partido para o ataque antes de
Atlas dar a ordem, provocando outro terremoto ao esmagar sua mão contra
o chão, seus quatro braços envoltos em correntes já partidas.
– Zeus – Kratos gritou do fundo de seus pulmões –, seu filho está de
volta! Eu trago a destruição do Olimpo!
Era o começo do Fim...
